﻿Add-Type -AssemblyName System.Windows.Forms
$dlg = New-Object System.Windows.Forms.FolderBrowserDialog
$dlg.Description = "请选择 QMT 安装目录（里面有 python 文件夹的那个）"
$dlg.ShowNewFolderButton = $false
$res = $dlg.ShowDialog()

if ($res -ne [System.Windows.Forms.DialogResult]::OK) {
    Write-Host "已取消" -ForegroundColor Yellow
    Read-Host "按回车退出"
    exit
}

$qmt = $dlg.SelectedPath
$layout = $qmt + "\python\formulaLayout"

Write-Host ""
Write-Host ("QMT 目录: " + $qmt)

if (-not (Test-Path ($qmt + "\python"))) {
    Write-Host "错误: 这个目录下没有 python 文件夹" -ForegroundColor Red
    Write-Host "请重新运行，选 QMT 的安装目录（不是 bin.x64 子目录）" -ForegroundColor Red
    Read-Host "按回车退出"
    exit
}

New-Item -ItemType Directory -Path $layout -Force | Out-Null

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$f1 = $here + "\打板Pro_买入.xml"
$f2 = $here + "\打板Pro_卖出.xml"

Copy-Item $f1 $layout -Force
Copy-Item $f1 ($layout + "\打板PRO_买入.xml") -Force
Copy-Item $f2 $layout -Force
Copy-Item $f2 ($layout + "\打板PRO_卖出.xml") -Force

Write-Host ""
Write-Host "完成，已复制 4 个文件到:" -ForegroundColor Green
Write-Host ("  " + $layout) -ForegroundColor Cyan
Write-Host ""
Write-Host "下一步:" -ForegroundColor Yellow
Write-Host "  1. 完全退出 QMT（托盘图标也要退出）" -ForegroundColor Yellow
Write-Host "  2. 重新打开 QMT" -ForegroundColor Yellow
Write-Host "  3. 策略交易 - 编辑 - 参数面板出现" -ForegroundColor Yellow
Write-Host ""
Read-Host "按回车退出"
